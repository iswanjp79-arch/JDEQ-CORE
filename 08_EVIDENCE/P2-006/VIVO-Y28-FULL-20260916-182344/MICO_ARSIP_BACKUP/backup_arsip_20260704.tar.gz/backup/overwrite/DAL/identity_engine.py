#!/usr/bin/env python3
import json, hashlib, os, socket
from pathlib import Path
from datetime import datetime

IDENTITY_FILE = Path.home() / "JDEQ/CONSTITUTION/digital_dna.json"
CONTINUITY_LOG = Path.home() / "JDEQ/AUDIT/identity_continuity.jsonl"

def init_identity():
    if not IDENTITY_FILE.exists():
        IDENTITY_FILE.parent.mkdir(parents=True, exist_ok=True)
        identity = {
            "system_name": "MICO-JDEQ",
            "owner": "Mas Iswan",
            "mission": "Cognitive Orchestration Platform",
            "birth_timestamp": datetime.now().isoformat(),
            "version": "3.0",
            "identity_hash": ""
        }
        identity["identity_hash"] = compute_identity_hash(identity)
        IDENTITY_FILE.write_text(json.dumps(identity, indent=2))
        return identity
    return json.loads(IDENTITY_FILE.read_text())

def compute_identity_hash(identity: dict) -> str:
    stable = {k: identity[k] for k in 
              ["system_name","owner","mission","birth_timestamp"] 
              if k in identity}
    return hashlib.sha256(json.dumps(stable, sort_keys=True).encode()).hexdigest()[:16]

def verify_continuity():
    identity = init_identity()
    current_hash = compute_identity_hash(identity)
    stored_hash = identity.get("identity_hash", "")
    
    result = {
        "timestamp": datetime.now().isoformat(),
        "identity_hash": current_hash,
        "continuity": current_hash == stored_hash,
        "status": "INTACT" if current_hash == stored_hash else "DRIFT_DETECTED"
    }
    
    CONTINUITY_LOG.parent.mkdir(parents=True, exist_ok=True)
    with open(CONTINUITY_LOG, "a") as f:
        f.write(json.dumps(result) + "\n")
    
    return result

if __name__ == "__main__":
    r = verify_continuity()
    print(f"Identity: {r['status']} | Hash: {r['identity_hash']}")
