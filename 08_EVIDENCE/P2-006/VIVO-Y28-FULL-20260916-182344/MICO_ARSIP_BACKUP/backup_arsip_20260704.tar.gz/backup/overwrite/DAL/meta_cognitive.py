#!/usr/bin/env python3
import json
from pathlib import Path
from datetime import datetime

EXEC_MEM = Path.home() / "JDEQ/cortex/executive_memory.jsonl"
META_LOG = Path.home() / "JDEQ/AUDIT/meta_cognitive.jsonl"

def think():
    decisions = []
    if EXEC_MEM.exists():
        lines = EXEC_MEM.read_text().strip().split("\n")
        decisions = [json.loads(l) for l in lines[-5:] if l]
    
    meta = {
        "timestamp": datetime.now().isoformat(),
        "total_decisions": len(decisions),
        "self_question": [
            "Apakah keputusan saya sudah optimal?",
            "Apa yang belum saya ketahui?",
            "Apa yang bisa diperbaiki?"
        ],
        "status": "REFLECTED"
    }
    
    META_LOG.parent.mkdir(parents=True, exist_ok=True)
    with open(META_LOG, "a") as f:
        f.write(json.dumps(meta, ensure_ascii=False) + "\n")
    
    print("🧠 Meta Cognitive: Selesai refleksi diri")
    return meta

if __name__ == "__main__":
    think()
