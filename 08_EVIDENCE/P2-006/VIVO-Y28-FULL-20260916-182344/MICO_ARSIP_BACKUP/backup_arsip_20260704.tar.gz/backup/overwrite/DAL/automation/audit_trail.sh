#!/data/data/com.termux/files/usr/bin/bash
echo "[$(date)] Audit: $(whoami) - $*" >> ~/JDEQ/logs/audit_trail.log
