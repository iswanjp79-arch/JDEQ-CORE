#!/usr/bin/env python3
"""MICO Task Planner - memecah misi menjadi task"""
import json, os, sys
from datetime import datetime

TASK_FILE = os.path.expanduser("~/JDEQ/DAL/tasks/tasks.json")
os.makedirs(os.path.dirname(TASK_FILE), exist_ok=True)

def load():
    if os.path.exists(TASK_FILE):
        with open(TASK_FILE) as f: return json.load(f)
    return {"tasks":[],"version":"1.0"}

def save(data):
    with open(TASK_FILE,'w') as f: json.dump(data,f,indent=2)

def decompose(mission_text):
    tasks = []
    for i, step in enumerate(mission_text.split(". ")):
        tasks.append({"id":f"T-{i+1:04d}","action":step,"status":"READY"})
    return tasks

if __name__ == "__main__":
    text = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else input("Misi: ")
    data = load()
    new_tasks = decompose(text)
    data["tasks"].extend(new_tasks)
    save(data)
    print(json.dumps(new_tasks, indent=2))
