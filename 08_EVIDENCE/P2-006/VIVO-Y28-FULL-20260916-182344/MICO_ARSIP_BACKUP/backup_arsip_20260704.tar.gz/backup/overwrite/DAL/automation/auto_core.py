#!/usr/bin/env python3
"""MICO Automation Core - menjalankan auto-heal & monitoring"""
import os, time, subprocess

def auto_heal_check():
    # Panggil auto_heal_network.sh
    subprocess.run(["bash", os.path.expanduser("~/JDEQ/bin/auto_heal_network.sh")])

if __name__ == "__main__":
    print("Automation Core ready")
