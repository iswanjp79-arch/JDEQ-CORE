#!/usr/bin/env python3
import os
POLICY = {"max_ram_mb":200,"require_audit":True}
print("Policy engine ready")
