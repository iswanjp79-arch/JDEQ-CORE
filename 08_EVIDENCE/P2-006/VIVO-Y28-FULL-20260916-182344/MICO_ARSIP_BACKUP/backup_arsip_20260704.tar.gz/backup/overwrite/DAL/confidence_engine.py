#!/usr/bin/env python3
import json, subprocess
from pathlib import Path
from datetime import datetime

CONFIDENCE_FILE = Path.home() / "JDEQ/AUDIT/confidence.json"

def assess():
    score = 100
    checks = []
    
    # Cek LLM
    llm = subprocess.run(["curl","-s","--max-time","3","http://localhost:8082/v1/models"], capture_output=True)
    if llm.returncode != 0:
        score -= 20; checks.append("LLM: OFFLINE")
    else:
        checks.append("LLM: ONLINE")
    
    # Cek Infinix
    ping = subprocess.run(["ping","-c","1","-W","1","100.103.39.81"], capture_output=True)
    if ping.returncode != 0:
        score -= 20; checks.append("Infinix: OFFLINE")
    else:
        checks.append("Infinix: ONLINE")
    
    # Cek RAM
    with open("/proc/meminfo") as f:
        for line in f:
            if "MemAvailable" in line:
                ram = int(line.split()[1]) // 1024
                if ram < 500: score -= 20; checks.append(f"RAM: LOW ({ram}MB)")
                else: checks.append(f"RAM: OK ({ram}MB)")
    
    # Tentukan aksi
    if score >= 95: action = "AUTO_EXECUTE"
    elif score >= 80: action = "RECOMMEND"
    else: action = "REQUEST_APPROVAL"
    
    result = {"timestamp": str(datetime.now()), "score": score, "action": action, "checks": checks}
    CONFIDENCE_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIDENCE_FILE.write_text(json.dumps(result, indent=2))
    print(f"Confidence: {score}% → {action}")
    return result

if __name__ == "__main__":
    assess()
