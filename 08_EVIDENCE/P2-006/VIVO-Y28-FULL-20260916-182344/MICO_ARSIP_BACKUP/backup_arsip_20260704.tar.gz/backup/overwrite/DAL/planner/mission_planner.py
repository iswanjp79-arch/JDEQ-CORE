#!/usr/bin/env python3
"""MICO Mission Planner v2.1 - Gate 4"""
import json, os, sys
from datetime import datetime

MISSION_FILE = os.path.expanduser("~/JDEQ/DAL/planner/missions.json")
os.makedirs(os.path.dirname(MISSION_FILE), exist_ok=True)

def load():
    if os.path.exists(MISSION_FILE):
        with open(MISSION_FILE) as f: return json.load(f)
    return {"missions":[],"version":"2.1"}

def save(data):
    with open(MISSION_FILE,'w') as f: json.dump(data,f,indent=2)

def plan(text):
    data = load()
    m = {"id":f"M-{len(data['missions'])+1:04d}","input":text,
         "timestamp":str(datetime.now()),"status":"PLANNED",
         "dependencies":[],"risk":"LOW","rollback":True}
    data["missions"].append(m)
    save(data)
    return m

if __name__ == "__main__":
    text = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else input("Misi: ")
    print(json.dumps(plan(text), indent=2))
