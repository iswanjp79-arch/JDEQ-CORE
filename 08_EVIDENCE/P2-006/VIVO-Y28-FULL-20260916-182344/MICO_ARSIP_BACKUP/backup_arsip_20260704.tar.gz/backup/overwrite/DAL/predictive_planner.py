#!/usr/bin/env python3
import json, subprocess, os
from pathlib import Path
from datetime import datetime

LOG = Path.home() / "JDEQ/AUDIT/predictions.jsonl"

def observe():
    obs = {}
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if "MemAvailable" in line:
                    obs["ram_mb"] = int(line.split()[1]) // 1024
    except: obs["ram_mb"] = 9999
    
    try:
        r = subprocess.run(["df", "-m", str(Path.home())], capture_output=True, text=True)
        parts = r.stdout.strip().split("\n")[-1].split()
        obs["disk_used_pct"] = int(parts[4].replace("%",""))
    except: obs["disk_used_pct"] = 0
    
    obs["hour"] = datetime.now().hour
    return obs

def predict(obs):
    warnings = []
    if obs.get("ram_mb", 9999) < 400:
        warnings.append({"type":"RAM","msg":f"RAM {obs['ram_mb']}MB","urgency":"HIGH"})
    if obs.get("disk_used_pct", 0) > 85:
        warnings.append({"type":"DISK","msg":f"Storage {obs['disk_used_pct']}%","urgency":"HIGH"})
    return warnings

def run():
    obs = observe()
    predictions = predict(obs)
    result = {"timestamp": datetime.now().isoformat(), "observations": obs, "predictions": predictions}
    
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG, "a") as f:
        f.write(json.dumps(result, ensure_ascii=False) + "\n")
    
    if predictions:
        print(f"🔮 {len(predictions)} prediksi:")
        for p in predictions:
            print(f"  [{p['type']}] {p['msg']} - {p['urgency']}")
    else:
        print("✅ Semua normal")

if __name__ == "__main__":
    run()
