#!/usr/bin/env python3
"""MICO Execution Dispatcher - menjalankan workflow"""
import json, os, subprocess, sys

def dispatch(workflow_id):
    # Di sini nanti membaca workflow dan menjalankannya
    return {"status":"dispatched","workflow_id":workflow_id}

if __name__ == "__main__":
    print('{"status":"dispatcher ready"}')
