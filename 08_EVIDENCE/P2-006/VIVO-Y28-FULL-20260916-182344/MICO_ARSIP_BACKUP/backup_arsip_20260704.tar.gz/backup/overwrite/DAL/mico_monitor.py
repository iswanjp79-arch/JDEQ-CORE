#!/usr/bin/env python3
# ~/JDEQ/DAL/mico_monitor.py
# MICO JDEQ — PERMANENT MONITOR v1.0
# Ringan, audit-ready, 1 jendela Termux

import os, json, time, sqlite3, subprocess
from pathlib import Path
from datetime import datetime

# ============================================================
# KONSTANTA
# ============================================================
HOME = Path.home()
JDEQ = HOME / "JDEQ"
NODES_DIR = JDEQ / "NODES"
SSOT_FILE = JDEQ / "SSOT_CANONICAL.json"
QUEUE_FILE = JDEQ / "RUNTIME/queue.json"
AUDIT_LOG = JDEQ / "AUDIT/identity_continuity.jsonl"
BRIDGE_LOG = JDEQ / "RUNTIME/pocketpal_bridge.log"
CORTEX_STATE = JDEQ / "cortex/cortex_state.json"

REFRESH = 10  # detik

# ============================================================
# WARNA ANSI — hanya untuk status, bukan hiasan
# ============================================================
R  = "\033[91m"   # merah   = kritis
Y  = "\033[93m"   # kuning  = waspada
G  = "\033[92m"   # hijau   = normal
B  = "\033[94m"   # biru    = info
W  = "\033[97m"   # putih   = label
DIM= "\033[2m"    # redup   = tidur/tidak aktif
RST= "\033[0m"    # reset
BLD= "\033[1m"    # tebal   = header

def clr(text, color): return f"{color}{text}{RST}"
def ok(t):   return clr(t, G)
def warn(t): return clr(t, Y)
def err(t):  return clr(t, R)
def dim(t):  return clr(t, DIM)
def inf(t):  return clr(t, B)
def lbl(t):  return clr(t, W)

# ============================================================
# DATA COLLECTORS — ringan, tidak boros CPU
# ============================================================
def get_ram():
    try:
        with open("/proc/meminfo") as f:
            lines = {l.split(":")[0]: int(l.split()[1])
                     for l in f if ":" in l and len(l.split()) >= 2}
        total = lines.get("MemTotal", 1)
        avail = lines.get("MemAvailable", total)
        used_pct = 100 - (avail * 100 // total)
        return used_pct, avail // 1024
    except:
        return 0, 0

def get_temp():
    try:
        with open("/sys/class/thermal/thermal_zone0/temp") as f:
            return int(f.read()) // 1000
    except:
        return 0

def get_battery():
    try:
        r = subprocess.run(["termux-battery-status"],
                          capture_output=True, text=True, timeout=3)
        d = json.loads(r.stdout)
        return d.get("percentage", 0), d.get("status", "?")
    except:
        return 0, "N/A"

def get_storage():
    try:
        r = subprocess.run(["df", "-m", str(HOME)],
                          capture_output=True, text=True)
        parts = r.stdout.strip().split("\n")[-1].split()
        return int(parts[4].replace("%", "")), int(parts[3])
    except:
        return 0, 0

def get_cpu():
    try:
        with open("/proc/loadavg") as f:
            load = float(f.read().split()[0])
        return min(int(load * 100), 100)
    except:
        return 0

def get_queue():
    try:
        if QUEUE_FILE.exists():
            q = json.loads(QUEUE_FILE.read_text())
            pending = sum(1 for t in q if t.get("status") == "pending")
            return len(q), pending
    except:
        pass
    return 0, 0

def get_ssot_version():
    try:
        if SSOT_FILE.exists():
            d = json.loads(SSOT_FILE.read_text())
            return d.get("version", d.get("ssot_version", "?"))
    except:
        pass
    return "?"

def get_nodes():
    nodes = {"active": [], "sleeping": [], "failed": []}
    if not NODES_DIR.exists():
        return nodes
    for db_file in sorted(NODES_DIR.glob("*.db")):
        nid = db_file.stem
        try:
            with sqlite3.connect(db_file, timeout=2) as db:
                row = db.execute(
                    "SELECT status, confidence FROM heartbeat "
                    "ORDER BY id DESC LIMIT 1"
                ).fetchone()
                if row:
                    status, conf = row
                    if status in ("alive", "thinking", "wake"):
                        nodes["active"].append((nid, conf))
                    elif status == "sleep":
                        nodes["sleeping"].append((nid, conf))
                    else:
                        nodes["failed"].append((nid, conf))
                else:
                    nodes["sleeping"].append((nid, 0.0))
        except:
            nodes["failed"].append((nid, 0.0))
    return nodes

def get_last_audit():
    try:
        if AUDIT_LOG.exists():
            lines = AUDIT_LOG.read_text().strip().split("\n")
            if lines and lines[-1]:
                d = json.loads(lines[-1])
                return d.get("timestamp", "?")[:19], d.get("status", "?")
    except:
        pass
    return "—", "—"

def get_last_bridge():
    try:
        if BRIDGE_LOG.exists():
            lines = BRIDGE_LOG.read_text().strip().split("\n")
            return lines[-1][-60:] if lines else "—"
    except:
        return "—"

def check_process(name):
    try:
        r = subprocess.run(["pgrep", "-f", name],
                          capture_output=True, text=True)
        return r.returncode == 0
    except:
        return False

def get_cortex_state():
    try:
        if CORTEX_STATE.exists():
            d = json.loads(CORTEX_STATE.read_text())
            mode = d.get("world", {}).get("kondisi", "?")
            opps = len(d.get("opportunities", []))
            return mode, opps
    except:
        pass
    return "?", 0

# ============================================================
# BAR RENDERER
# ============================================================
def bar(pct, width=12, warn_at=70, err_at=90):
    filled = int(pct * width // 100)
    empty = width - filled
    color = R if pct >= err_at else Y if pct >= warn_at else G
    return f"{color}{'█' * filled}{DIM}{'░' * empty}{RST}"

def status_dot(ok_val):
    return ok("●") if ok_val else err("●")

# ============================================================
# RENDER SECTIONS
# ============================================================
def render_header(ssot_ver, global_ok):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    gstatus = ok("● OPERATIONAL") if global_ok else err("● DEGRADED")
    print(f"\n{BLD}╔══════════════════════════════════════════════════════╗{RST}")
    print(f"{BLD}║  MICO JDEQ — DISTRIBUTED COGNITIVE MESH MONITOR     ║{RST}")
    print(f"{BLD}╠══════════════════════════════════════════════════════╣{RST}")
    print(f"{BLD}║{RST}  {lbl('Time:')} {inf(now)}  {lbl('SSOT:')} {inf(ssot_ver)}")
    print(f"{BLD}║{RST}  {lbl('Global:')} {gstatus}")
    print(f"{BLD}╚══════════════════════════════════════════════════════╝{RST}")

def render_health(cpu, ram_pct, ram_mb, stor_pct, stor_mb,
                  batt, batt_st, temp, q_total, q_pend):
    print(f"\n{BLD}── HEALTH ─────────────────────────────────────────────{RST}")
    print(f"  {lbl('CPU')}  {bar(cpu,10,60,85)} {cpu:3d}%  "
          f"{lbl('RAM')}  {bar(ram_pct,10,70,90)} {ram_pct:3d}% ({ram_mb}MB free)")
    b_color = R if batt < 15 else Y if batt < 30 else G
    t_color = R if temp > 40 else Y if temp > 36 else G
    print(f"  {lbl('STOR')} {bar(stor_pct,10,75,90)} {stor_pct:3d}% ({stor_mb}MB free)")
    print(f"  {lbl('BATT')} {b_color}{batt:3d}%{RST} [{batt_st}]  "
          f"{lbl('TEMP')} {t_color}{temp:2d}°C{RST}")
    q_color = R if q_pend > 5 else Y if q_pend > 2 else G
    print(f"  {lbl('QUEUE')} total={q_color}{q_total}{RST} pending={q_color}{q_pend}{RST}")

def render_connections(procs):
    print(f"\n{BLD}── CONNECTIONS ─────────────────────────────────────────{RST}")
    items = [
        ("Ghost Runner",  procs.get("mico_combined")),
        ("Bridge Server", procs.get("pocketpal_bridge")),
        ("Cloudflared",   procs.get("cloudflared")),
        ("Tailscale",     procs.get("tailscaled")),
        ("Cortex",        procs.get("executive_cortex")),
        ("Predictive",    procs.get("predictive_planner")),
    ]
    line1 = "  "
    line2 = "  "
    for i, (name, alive) in enumerate(items):
        dot = ok("▶") if alive else err("▷")
        label = f"{dot} {name:<15}"
        if i % 2 == 0:
            line1 += label
        else:
            line2 += label
    print(line1)
    print(line2)

def render_nodes(nodes, cortex_mode, opps):
    active = nodes["active"]
    sleeping = nodes["sleeping"]
    failed = nodes["failed"]
    total = len(active) + len(sleeping) + len(failed)

    print(f"\n{BLD}── NODE ZONE [{total} nodes] ──────────────────────────────{RST}")
    print(f"  {lbl('Cortex Mode:')} {inf(cortex_mode)}  "
          f"{lbl('Opportunities:')} {inf(str(opps))}")

    # Active nodes
    if active:
        print(f"  {ok('▶ ACTIVE')} ({len(active)})", end="")
        for nid, conf in active[:6]:
            c_color = G if conf > 0.7 else Y if conf > 0.4 else R
            print(f"  {nid}[{c_color}{conf:.2f}{RST}]", end="")
        print()

    # Sleeping nodes
    if sleeping:
        print(f"  {dim('◌ SLEEP')}  ({len(sleeping)})", end="")
        for nid, conf in sleeping[:6]:
            print(f"  {dim(nid)}[{dim(f'{conf:.2f}')}]", end="")
        if len(sleeping) > 6:
            print(f"  {dim(f'+{len(sleeping)-6} more')}", end="")
        print()

    # Failed nodes
    if failed:
        print(f"  {err('✗ FAILED')} ({len(failed)})", end="")
        for nid, conf in failed:
            print(f"  {err(nid)}", end="")
        print()

    # Confidence drift warning
    all_conf = [c for _, c in active + sleeping]
    if all_conf:
        avg_conf = sum(all_conf) / len(all_conf)
        drift = max(all_conf) - min(all_conf) if len(all_conf) > 1 else 0
        c_color = R if avg_conf < 0.4 else Y if avg_conf < 0.6 else G
        print(f"  {lbl('Avg Confidence:')} {c_color}{avg_conf:.3f}{RST}  "
              f"{lbl('Drift:')} {warn(f'{drift:.3f}') if drift > 0.3 else ok(f'{drift:.3f}')}")

def render_audit(last_audit_ts, last_audit_status, last_bridge):
    print(f"\n{BLD}── AUDIT ZONE ──────────────────────────────────────────{RST}")
    a_color = G if last_audit_status == "INTACT" else \
              R if last_audit_status == "DRIFT_DETECTED" else Y
    print(f"  {lbl('Last Identity Check:')} {inf(last_audit_ts)} "
          f"→ {a_color}{last_audit_status}{RST}")
    print(f"  {lbl('Last Bridge:')} {dim(last_bridge[-55:])}")

def render_alerts(alerts):
    if not alerts:
        return
    print(f"\n{BLD}── ALERTS ──────────────────────────────────────────────{RST}")
    for level, msg in alerts:
        if level == "CRITICAL":
            print(f"  {err('⚠ CRITICAL')} {msg}")
        elif level == "WARNING":
            print(f"  {warn('△ WARNING')} {msg}")
        else:
            print(f"  {inf('ℹ INFO')} {msg}")

def render_recovery():
    print(f"\n{BLD}── RECOVERY ZONE ───────────────────────────────────────{RST}")
    backup_dir = JDEQ / "BACKUP"
    backups = sorted(backup_dir.glob("*.tar*")) if backup_dir.exists() else []
    last_bak = backups[-1].name if backups else "—"
    ssot_ok = SSOT_FILE.exists()
    nodes_ok = NODES_DIR.exists()
    print(f"  {lbl('Last Backup:')}  {inf(last_bak)}")
    print(f"  {lbl('SSOT Ready:')}   {ok('YES') if ssot_ok else err('NO')}")
    print(f"  {lbl('Nodes Ready:')}  {ok('YES') if nodes_ok else err('NO')}")
    print(f"  {lbl('Restore CMD:')}  {dim('bash ~/JDEQ/RECOVERY/restore.sh')}")
    print(f"{BLD}────────────────────────────────────────────────────────{RST}")

def render_footer():
    print(f"\n  {dim(f'Refresh: {REFRESH}s  |  Ctrl+C to exit  |  '
                    f'Log: ~/JDEQ/AUDIT/')}")

# ============================================================
# ALERT BUILDER
# ============================================================
def build_alerts(ram_pct, batt, temp, q_pend,
                 cpu, stor_pct, failed_nodes,
                 audit_status):
    alerts = []
    if ram_pct > 90:
        alerts.append(("CRITICAL", f"RAM {ram_pct}% — kurangi beban segera"))
    elif ram_pct > 75:
        alerts.append(("WARNING", f"RAM {ram_pct}% — mendekati batas"))
    if temp > 42:
        alerts.append(("CRITICAL", f"Suhu {temp}°C — hentikan proses berat"))
    elif temp > 38:
        alerts.append(("WARNING", f"Suhu {temp}°C — pantau terus"))
    if batt < 10:
        alerts.append(("CRITICAL", f"Baterai {batt}% — sambungkan charger"))
    elif batt < 20:
        alerts.append(("WARNING", f"Baterai {batt}%"))
    if q_pend > 5:
        alerts.append(("CRITICAL", f"Queue pending {q_pend} — Ghost Runner aktif?"))
    elif q_pend > 2:
        alerts.append(("WARNING", f"Queue pending {q_pend}"))
    if stor_pct > 90:
        alerts.append(("CRITICAL", f"Storage {stor_pct}% — bersihkan log lama"))
    if failed_nodes:
        alerts.append(("CRITICAL", f"Node gagal: {', '.join(failed_nodes)}"))
    if audit_status == "DRIFT_DETECTED":
        alerts.append(("CRITICAL", "Identity drift terdeteksi — cek SSOT"))
    if cpu > 85:
        alerts.append(("WARNING", f"CPU load {cpu}%"))
    return alerts

# ============================================================
# MAIN LOOP
# ============================================================
def main():
    os.system("clear")
    print(inf("  MICO JDEQ Monitor — memulai..."))
    time.sleep(1)

    while True:
        try:
            # Collect semua data
            cpu = get_cpu()
            ram_pct, ram_mb = get_ram()
            temp = get_temp()
            batt, batt_st = get_battery()
            stor_pct, stor_mb = get_storage()
            q_total, q_pend = get_queue()
            ssot_ver = get_ssot_version()
            nodes = get_nodes()
            audit_ts, audit_status = get_last_audit()
            last_bridge = get_last_bridge()
            cortex_mode, opps = get_cortex_state()

            # Process checks
            procs = {
                "mico_combined":    check_process("mico_combined"),
                "pocketpal_bridge": check_process("pocketpal_bridge"),
                "cloudflared":      check_process("cloudflared"),
                "tailscaled":       check_process("tailscaled"),
                "executive_cortex": check_process("executive_cortex"),
                "predictive_planner":check_process("predictive_planner"),
            }

            # Build alerts
            failed_node_ids = [n for n, _ in nodes["failed"]]
            alerts = build_alerts(ram_pct, batt, temp, q_pend,
                                  cpu, stor_pct, failed_node_ids,
                                  audit_status)

            # Global health
            global_ok = (len(alerts) == 0 or
                        not any(a[0] == "CRITICAL" for a in alerts))

            # Render
            os.system("clear")
            render_header(ssot_ver, global_ok)
            render_health(cpu, ram_pct, ram_mb, stor_pct, stor_mb,
                         batt, batt_st, temp, q_total, q_pend)
            render_connections(procs)
            render_nodes(nodes, cortex_mode, opps)
            render_audit(audit_ts, audit_status, last_bridge)
            render_alerts(alerts)
            render_recovery()
            render_footer()

            time.sleep(REFRESH)

        except KeyboardInterrupt:
            os.system("clear")
            print(ok("\n  MICO Monitor dihentikan. Sistem tetap berjalan.\n"))
            break
        except Exception as e:
            print(err(f"\n  Monitor error: {e}"))
            time.sleep(5)

if __name__ == "__main__":
    main()
