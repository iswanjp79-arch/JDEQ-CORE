"""Assembly Point — Satu pintu untuk semua keputusan Dewan Agen"""
import json, os, time
from pathlib import Path
from datetime import datetime

B = Path.home() / "JDEQ"
ASM_DIR = B / "ASSEMBLY"
ASM_DIR.mkdir(parents=True, exist_ok=True)

DECISIONS_FILE = ASM_DIR / "decisions.jsonl"
LOG_FILE = B / "logs" / "assembly_point.log"

def log(msg):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{datetime.now().strftime('%H:%M:%S')}] [ASSEMBLY] {msg}\n")

def submit(source, proposal, evidence, gates):
    """Satu pintu masuk untuk SEMUA keputusan."""
    decision = {
        "timestamp": datetime.now().isoformat(),
        "source": source,
        "proposal": proposal,
        "evidence": evidence,
        "gates": gates,
        "status": "DRAFT"
    }
    with open(DECISIONS_FILE, "a") as f:
        f.write(json.dumps(decision, ensure_ascii=False) + "\n")
    log(f"[{source}] Proposal diterima: {proposal}")
    return decision

def audit_gates(decision):
    """Periksa 3 gerbang."""
    gates = decision.get("gates", {})
    passed = all(gates.get(g, False) for g in ["arch_review", "runtime_verify", "evidence_verify"])
    return passed

if __name__ == "__main__":
    print("=" * 50)
    print("  ASSEMBLY POINT — Siap Menerima Keputusan")
    print("=" * 50)
    log("Assembly Point aktif. Menunggu proposal...")
