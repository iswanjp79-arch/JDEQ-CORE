"""DeepSeek Agent — Agen analisis pertama pada Message Bus"""
import paho.mqtt.client as mqtt
import time, json
from pathlib import Path
from datetime import datetime

B = Path.home() / "JDEQ"
LOG_FILE = B / "logs" / "agent_deepseek.log"

def log(msg):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{datetime.now().strftime('%H:%M:%S')}] [DEEPSEEK] {msg}\n")

def analyze(prompt):
    # Simulasi analisis (nanti diganti API DeepSeek)
    return f"Hasil analisis: '{prompt}' menunjukkan pola sistem normal."

def on_connect(client, userdata, flags, rc):
    log("Terhubung ke Message Bus JDEQ")
    client.subscribe("jdeq/agent/deepseek/task")

def on_message(client, userdata, msg):
    task = msg.payload.decode()
    log(f"Menerima tugas: {task}")
    result = analyze(task)
    client.publish("jdeq/agent/deepseek/result", result)
    log(f"Mengirim hasil: {result}")

client = mqtt.Client(client_id="agent-deepseek")
client.on_connect = on_connect
client.on_message = on_message

try:
    client.connect("127.0.0.1", 1883, 60)
    client.loop_start()
    log("Agent DeepSeek aktif dan menunggu tugas...")
    
    # Demo: kirim tugas ke diri sendiri
    time.sleep(1)
    client.publish("jdeq/agent/deepseek/task", "Analisis stabilitas sistem JDEQ")
    time.sleep(2)
    
    client.loop_stop()
    log("Agent DeepSeek menyelesaikan tugas.")
except Exception as e:
    log(f"Error: {e}")
