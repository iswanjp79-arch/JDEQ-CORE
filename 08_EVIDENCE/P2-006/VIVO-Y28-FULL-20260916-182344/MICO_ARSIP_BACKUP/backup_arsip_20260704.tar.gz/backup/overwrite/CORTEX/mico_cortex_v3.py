"""MICO Cortex V3 — Event-Driven + AI Router (Otak Buatan)"""
import os, time, subprocess, threading, json, sys
from pathlib import Path
from datetime import datetime
import paho.mqtt.client as mqtt
from loguru import logger

B = Path.home() / "JDEQ"
sys.path.insert(0, str(B / "CORTEX"))
sys.path.insert(0, str(B / "CORTEX" / "router"))

from workflow_engine import execute_workflow
from policy_engine_v2 import validate_event
from device_lock import karantina
from ai_router import call_ai, list_providers

LOG_FILE = B / "logs" / "mico_cortex_v3.log"
logger.add(LOG_FILE, rotation="1 week", level="INFO")

QUEUE_MAIN = B / "queue" / "main"
GHOST_RUNNER = B / "scripts" / "ghost_runner.sh"
TOPIC_EVENT = "jdeq/events"
TOPIC_NOTIF = "jdeq/dewan/notifikasi"
TOPIC_AI_RESPONSE = "jdeq/ai/response"

DEFAULT_AI = "deepseek"  # Default AI untuk analisis event

def on_connect(client, userdata, flags, rc):
    logger.info("MICO Cortex V3 (AI-Powered) terhubung ke Event Bus")
    client.subscribe(TOPIC_EVENT)
    client.subscribe(TOPIC_NOTIF)

def on_message(client, userdata, msg):
    payload = msg.payload.decode()
    topic = msg.topic

    if topic == TOPIC_EVENT:
        # Parse event
        parts = payload.split("] ")
        if len(parts) >= 3:
            event_type = parts[1].replace("[", "")
            detail = "] ".join(parts[2:])
        else:
            event_type = "UNKNOWN"
            detail = payload

        logger.info(f"EVENT: {event_type} — {detail}")

        # Policy Check
        allowed, action = validate_event(event_type, detail)
        if allowed:
            execute_workflow(event_type, detail)

            # AI ANALYSIS — Kirim event ke AI Router
            ai_prompt = f"Sebagai MICO OS Orchestrator, analisis event ini: [{event_type}] {detail}. Berikan rekomendasi tindakan dalam 1 kalimat."
            ai_response = call_ai(DEFAULT_AI, ai_prompt)
            logger.info(f"AI RESPONSE ({DEFAULT_AI}): {ai_response[:100] if ai_response else 'N/A'}")

            # Publish AI response ke topik khusus
            if ai_response and not ai_response.startswith("❌"):
                client.publish(TOPIC_AI_RESPONSE, ai_response)
                client.publish(TOPIC_NOTIF, f"[MICO AI] {ai_response[:200]}")
            else:
                logger.warning(f"AI tidak tersedia: {ai_response}")
                client.publish(TOPIC_NOTIF, f"[MICO] Event {event_type} diproses tanpa AI (API key belum diisi).")
        else:
            karantina(event_type, detail)
            logger.warning(f"Event {event_type} DIKARANTINA")
            client.publish(TOPIC_NOTIF, f"[MICO] Event {event_type} DIKARANTINA: {detail}")

    elif topic == TOPIC_NOTIF:
        logger.info(f"NOTIFIKASI: {payload}")

client = mqtt.Client(client_id="mico-cortex-v3")
client.on_connect = on_connect
client.on_message = on_message
client.connect("127.0.0.1", 1883, 60)

logger.info("MICO Cortex V3 (AI-Powered) aktif")

def ghost_loop():
    while True:
        if os.path.exists(QUEUE_MAIN) and os.listdir(QUEUE_MAIN):
            logger.info("Task ditemukan. Menjalankan Ghost Runner.")
            subprocess.run(["bash", str(GHOST_RUNNER)])
        time.sleep(5)

threading.Thread(target=ghost_loop, daemon=True).start()

# Tampilkan status AI provider
providers = list_providers()
logger.info(f"AI Providers tersedia: {len(providers)} — {', '.join(providers[:5])}...")

client.loop_forever()
