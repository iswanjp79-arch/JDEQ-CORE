"""Symlink Think — Kontrol Aplikasi via Symlink"""
import os, json
from pathlib import Path

B = Path.home() / "JDEQ"
SYMLINK_DIR = B / "SYMLINK"
KARANTINA = B / "KARANTINA"
APPS_DIR = Path.home() / "storage" / "downloads"

ALLOWED_APPS = ["termux", "jdeq", "mico"]

def update_symlinks():
    SYMLINK_DIR.mkdir(parents=True, exist_ok=True)
    KARANTINA.mkdir(parents=True, exist_ok=True)
    for app in ALLOWED_APPS:
        target = APPS_DIR / f"{app}.apk"
        link = SYMLINK_DIR / f"{app}.apk"
        if target.exists():
            if not link.exists():
                os.symlink(target, link)
                print(f"✅ Symlink dibuat: {app}")
        else:
            print(f"⚠️  Target tidak ditemukan: {app}")

if __name__ == "__main__":
    update_symlinks()
