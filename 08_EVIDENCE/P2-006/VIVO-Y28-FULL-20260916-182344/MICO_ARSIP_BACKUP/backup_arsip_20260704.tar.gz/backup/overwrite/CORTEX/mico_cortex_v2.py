"""MICO Cortex V2 — Event-Driven + Policy + Workflow + Device Lock"""
import os, time, subprocess, threading, json
from pathlib import Path
from datetime import datetime
import paho.mqtt.client as mqtt
from loguru import logger
import sys

B = Path.home() / "JDEQ"
sys.path.insert(0, str(B / "CORTEX"))

from workflow_engine import execute_workflow
from policy_engine_v2 import validate_event
from device_lock import karantina

LOG_FILE = B / "logs" / "mico_cortex_v2.log"
logger.add(LOG_FILE, rotation="1 week", level="INFO")

QUEUE_MAIN = B / "queue" / "main"
GHOST_RUNNER = B / "scripts" / "ghost_runner.sh"
TOPIC_EVENT = "jdeq/events"
TOPIC_NOTIF = "jdeq/dewan/notifikasi"

def on_connect(client, userdata, flags, rc):
    logger.info("MICO Cortex V2 terhubung ke Event Bus")
    client.subscribe(TOPIC_EVENT)
    client.subscribe(TOPIC_NOTIF)

def on_message(client, userdata, msg):
    payload = msg.payload.decode()
    topic = msg.topic

    if topic == TOPIC_EVENT:
        # Parse event: [TIMESTAMP] [TYPE] DETAIL
        parts = payload.split("] ")
        if len(parts) >= 3:
            event_type = parts[1].replace("[", "")
            detail = "] ".join(parts[2:])
        else:
            event_type = "UNKNOWN"
            detail = payload

        logger.info(f"EVENT: {event_type} — {detail}")

        # Policy Check
        allowed, action = validate_event(event_type, detail)
        if allowed:
            # Jalankan Workflow
            execute_workflow(event_type, detail)
            client.publish(TOPIC_NOTIF, f"[MICO] Event {event_type} diproses: {detail}")
        else:
            # Karantina
            karantina(event_type, detail)
            logger.warning(f"Event {event_type} DIKARANTINA")
            client.publish(TOPIC_NOTIF, f"[MICO] Event {event_type} DIKARANTINA: {detail}")

    elif topic == TOPIC_NOTIF:
        logger.info(f"NOTIFIKASI: {payload}")

client = mqtt.Client(client_id="mico-cortex-v2")
client.on_connect = on_connect
client.on_message = on_message
client.connect("127.0.0.1", 1883, 60)

logger.info("MICO Cortex V2 aktif — Full Event-Driven + Policy + Workflow + Device Lock")

def ghost_loop():
    while True:
        if os.path.exists(QUEUE_MAIN) and os.listdir(QUEUE_MAIN):
            logger.info("Task ditemukan. Menjalankan Ghost Runner.")
            subprocess.run(["bash", str(GHOST_RUNNER)])
        time.sleep(5)

threading.Thread(target=ghost_loop, daemon=True).start()
client.loop_forever()
