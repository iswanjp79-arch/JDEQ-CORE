"""MICO Message Bus — Event Bus + Response Merger"""
import json, os, threading, time
from pathlib import Path
from datetime import datetime

B = Path.home() / "JDEQ"
BUS_FILE = B / "RUNTIME" / "message_bus.json"
MERGE_FILE = B / "RUNTIME" / "merged_responses.json"

class MessageBus:
    def __init__(self):
        self.queue = self._load(BUS_FILE)
        self.responses = self._load(MERGE_FILE)
    
    def _load(self, path):
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            return json.loads(path.read_text())
        return {"messages": [], "responses": []}
    
    def _save(self, path, data):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    
    def publish(self, intent, agent, prompt):
        """Kirim pesan ke agen."""
        msg = {
            "id": datetime.now().strftime("%Y%m%d%H%M%S%f"),
            "intent": intent,
            "agent": agent,
            "prompt": prompt[:200],
            "status": "PENDING",
            "timestamp": datetime.now().isoformat()
        }
        self.queue["messages"].append(msg)
        self._save(BUS_FILE, self.queue)
        return msg["id"]
    
    def receive(self, msg_id, response):
        """Terima respons dari agen."""
        for msg in self.queue["messages"]:
            if msg["id"] == msg_id:
                msg["status"] = "DONE"
                msg["response"] = response[:500]
                self._save(BUS_FILE, self.queue)
                
                # Simpan ke merged responses
                self.responses["responses"].append({
                    "msg_id": msg_id,
                    "agent": msg["agent"],
                    "response": response[:500],
                    "timestamp": datetime.now().isoformat()
                })
                self._save(MERGE_FILE, self.responses)
                return True
        return False
    
    def merge_responses(self):
        """Gabungkan semua respons terbaru."""
        recent = self.responses["responses"][-5:]
        merged = {
            "total_responses": len(recent),
            "agents_responded": list(set(r["agent"] for r in recent)),
            "latest": recent[-1] if recent else None,
            "all": recent
        }
        return merged

# Singleton
bus = MessageBus()
print("Message Bus siap.")
