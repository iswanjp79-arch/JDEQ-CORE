"""Event Bridge — Menjembatani Detector ke Event Bus (MQTT)"""
import os, time, subprocess, threading
from pathlib import Path
from datetime import datetime
import paho.mqtt.client as mqtt

B = Path.home() / "JDEQ"
EVENT_FILE = B / "logs" / "detector" / "events.log"
LOG_FILE = B / "logs" / "bridge.log"

def log(msg):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{datetime.now().strftime('%H:%M:%S')}] [BRIDGE] {msg}\n")

MQTT_BROKER = "127.0.0.1"
TOPIC_EVENT = "jdeq/events"

client = mqtt.Client(client_id="event-bridge")
client.connect(MQTT_BROKER, 1883, 60)
log("Bridge terhubung ke MQTT")

# Monitor event file (tail -f)
last_pos = os.path.getsize(EVENT_FILE) if os.path.exists(EVENT_FILE) else 0

while True:
    if os.path.exists(EVENT_FILE):
        current_size = os.path.getsize(EVENT_FILE)
        if current_size > last_pos:
            with open(EVENT_FILE) as f:
                f.seek(last_pos)
                for line in f:
                    line = line.strip()
                    if line:
                        client.publish(TOPIC_EVENT, line)
                        log(f"Event → MQTT: {line[:80]}")
            last_pos = current_size
    time.sleep(1)
