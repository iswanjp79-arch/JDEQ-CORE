"""Device Lock — Karantina perubahan yang tidak sah"""
import json, os
from pathlib import Path
from datetime import datetime

B = Path.home() / "JDEQ"
KARANTINA_DIR = B / "KARANTINA"
KARANTINA_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = B / "logs" / "device_lock.log"

def log(msg):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{datetime.now().strftime('%H:%M:%S')}] [LOCK] {msg}\n")

def karantina(event_type, detail):
    """Pindahkan file/event mencurigakan ke karantina."""
    record = {
        "timestamp": datetime.now().isoformat(),
        "event_type": event_type,
        "detail": detail,
        "status": "DIKARANTINA"
    }
    file_name = f"karantina_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(KARANTINA_DIR / file_name, "w") as f:
        json.dump(record, f, indent=2)
    log(f"Karantina: {event_type} → {file_name}")

if __name__ == "__main__":
    log("Device Lock siap.")
