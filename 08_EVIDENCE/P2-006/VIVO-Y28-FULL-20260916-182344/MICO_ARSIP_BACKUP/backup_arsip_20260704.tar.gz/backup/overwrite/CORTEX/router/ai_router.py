"""AI Router — Satu pintu untuk 10 model AI via Termux"""
import os, json, time, requests
from pathlib import Path
from datetime import datetime

B = Path.home() / "JDEQ"
LOG_FILE = B / "logs" / "ai_router.log"
VAULT_DIR = B / "ANANDA_MADINA" / "api"

ENDPOINTS = {
    "openai": {
        "url": "https://api.openai.com/v1/chat/completions",
        "model": "gpt-4o",
        "header_key": "Authorization",
        "header_prefix": "Bearer "
    },
    "gemini": {
        "url": "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent",
        "model": "gemini-1.5-flash",
        "header_key": "x-goog-api-key",
        "header_prefix": ""
    },
    "claude": {
        "url": "https://api.anthropic.com/v1/messages",
        "model": "claude-3-5-sonnet-20241022",
        "header_key": "x-api-key",
        "header_prefix": ""
    },
    "deepseek": {
        "url": "https://api.deepseek.com/v1/chat/completions",
        "model": "deepseek-chat",
        "header_key": "Authorization",
        "header_prefix": "Bearer "
    },
    "groq": {
        "url": "https://api.groq.com/openai/v1/chat/completions",
        "model": "llama-3.1-8b-instant",
        "header_key": "Authorization",
        "header_prefix": "Bearer "
    },
    "cerebras": {
        "url": "https://api.cerebras.ai/v1/chat/completions",
        "model": "llama3.1-8b",
        "header_key": "Authorization",
        "header_prefix": "Bearer "
    },
    "perplexity": {
        "url": "https://api.perplexity.ai/chat/completions",
        "model": "llama-3.1-sonar-small-128k-online",
        "header_key": "Authorization",
        "header_prefix": "Bearer "
    },
    "mistral": {
        "url": "https://api.mistral.ai/v1/chat/completions",
        "model": "mistral-small-latest",
        "header_key": "Authorization",
        "header_prefix": "Bearer "
    },
    "cohere": {
        "url": "https://api.cohere.ai/v1/chat",
        "model": "command-r-plus",
        "header_key": "Authorization",
        "header_prefix": "Bearer "
    },
    "together": {
        "url": "https://api.together.xyz/v1/chat/completions",
        "model": "mistralai/Mixtral-8x7B-Instruct-v0.1",
        "header_key": "Authorization",
        "header_prefix": "Bearer "
    }
}

def log(msg):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{datetime.now().strftime('%H:%M:%S')}] [ROUTER] {msg}\n")

def load_api_key(provider):
    """Membaca API key dari vault."""
    key_file = VAULT_DIR / f"{provider}.gpg"
    if key_file.exists():
        with open(key_file) as f:
            return f.read().strip()
    return None

def call_ai(provider, prompt, max_tokens=100):
    """Memanggil API AI."""
    if provider not in ENDPOINTS:
        return f"❌ Provider '{provider}' tidak dikenal."

    cfg = ENDPOINTS[provider]
    api_key = load_api_key(provider)

    if not api_key:
        return f"❌ API key untuk {provider} tidak ditemukan di vault."

    headers = {
        "Content-Type": "application/json",
        cfg["header_key"]: cfg["header_prefix"] + api_key
    }

    if provider == "gemini":
        data = {
            "contents": [{"parts": [{"text": prompt}]}]
        }
    elif provider == "claude":
        data = {
            "model": cfg["model"],
            "max_tokens": max_tokens,
            "messages": [{"role": "user", "content": prompt}]
        }
    else:
        data = {
            "model": cfg["model"],
            "max_tokens": max_tokens,
            "messages": [{"role": "user", "content": prompt}]
        }

    try:
        resp = requests.post(cfg["url"], headers=headers, json=data, timeout=30)
        if resp.status_code == 200:
            result = resp.json()
            if provider == "gemini":
                text = result["candidates"][0]["content"]["parts"][0]["text"]
            elif provider == "claude":
                text = result["content"][0]["text"]
            else:
                text = result["choices"][0]["message"]["content"]
            log(f"{provider} → SUCCESS ({len(text)} chars)")
            return text
        else:
            log(f"{provider} → HTTP {resp.status_code}")
            return f"❌ {provider} error: {resp.status_code}"
    except Exception as e:
        log(f"{provider} → EXCEPTION: {e}")
        return f"❌ {provider} exception: {str(e)[:80]}"

def list_providers():
    """Menampilkan semua provider yang tersedia."""
    return list(ENDPOINTS.keys())

if __name__ == "__main__":
    print("=" * 50)
    print("  AI ROUTER — 10 Model AI Siap")
    print("=" * 50)
    for p in ENDPOINTS:
        key_status = "✅" if load_api_key(p) else "⬜ (butuh API key)"
        print(f"  {p:12} → {ENDPOINTS[p]['model']:30} {key_status}")
    print("=" * 50)
    log("AI Router diinisialisasi.")
