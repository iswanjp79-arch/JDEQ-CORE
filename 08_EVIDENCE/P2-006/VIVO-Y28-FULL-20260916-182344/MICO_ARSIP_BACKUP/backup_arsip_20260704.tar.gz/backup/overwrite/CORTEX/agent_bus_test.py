import paho.mqtt.client as mqtt
import time, json
from pathlib import Path
from datetime import datetime

B = Path.home() / "JDEQ"
LOG_FILE = B / "logs" / "agent_bus.log"

def log(msg):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{datetime.now().strftime('%H:%M:%S')}] [BUS-TEST] {msg}\n")

def on_connect(client, userdata, flags, rc):
    log(f"Terhubung ke broker dengan kode {rc}")
    client.subscribe("jdeq/bus/test")

def on_message(client, userdata, msg):
    pesan = msg.payload.decode()
    log(f"Pesan diterima dari {msg.topic}: {pesan}")

client = mqtt.Client(client_id="agent-bus-test")
client.on_connect = on_connect
client.on_message = on_message

try:
    client.connect("127.0.0.1", 1883, 60)
    client.loop_start()
    time.sleep(1)
    client.publish("jdeq/bus/test", "Pesan percobaan dari agen uji")
    log("Pesan terkirim ke jdeq/bus/test")
    time.sleep(2)
    client.loop_stop()
    client.disconnect()
except Exception as e:
    log(f"Error: {e}")
