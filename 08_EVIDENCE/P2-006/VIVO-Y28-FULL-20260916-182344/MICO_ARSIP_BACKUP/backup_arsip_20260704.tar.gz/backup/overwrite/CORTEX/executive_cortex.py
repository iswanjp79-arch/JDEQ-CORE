"""MICO Executive Cortex — SATU otak utama."""
import json, os
from pathlib import Path
from datetime import datetime

B = Path.home() / "JDEQ"

def load_constitution():
    with open(B / "CONSTITUTION" / "identity.json") as f:
        return json.load(f)

def load_registry():
    with open(B / "GOVERNANCE" / "dewan_agen_registry.json") as f:
        return json.load(f)

def route_to_agent(intent):
    """Route intent ke agen yang tepat berdasarkan registry."""
    registry = load_registry()
    routing = {
        "audit": "claude",
        "execute": "deepseek",
        "strategy": "gemini",
        "parse": "chatgpt",
        "document": "copilot_microsoft",
        "verify": "dola",
        "research": "perplexity",
        "debug": "copilot_github",
        "evolve": "emergent"
    }
    return routing.get(intent, "chatgpt")

def log_decision(intent, agent):
    with open(B / "GOVERNANCE" / "decision_log.jsonl", "a") as f:
        f.write(json.dumps({"timestamp": datetime.now().isoformat(), "intent": intent, "agent": agent}) + "\n")

if __name__ == "__main__":
    identity = load_constitution()
    print(f"MICO Executive Cortex v{identity['version']} — Siap.")
