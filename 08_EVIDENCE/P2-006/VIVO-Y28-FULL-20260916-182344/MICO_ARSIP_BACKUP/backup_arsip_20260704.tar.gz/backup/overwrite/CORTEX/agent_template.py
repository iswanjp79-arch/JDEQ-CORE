"""Template Agen JDEQ — Satu agen, satu peran, satu topik MQTT"""
import paho.mqtt.client as mqtt
import time
from pathlib import Path
from datetime import datetime

class JDQAgent:
    def __init__(self, name, role, subscribe_topic, publish_topic):
        self.name = name
        self.role = role
        self.sub_topic = subscribe_topic
        self.pub_topic = publish_topic
        self.log_file = Path.home() / "JDEQ" / "logs" / f"agent_{name}.log"
        self.client = mqtt.Client(client_id=f"agent-{name}")
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message

    def log(self, msg):
        with open(self.log_file, "a") as f:
            f.write(f"[{datetime.now().strftime('%H:%M:%S')}] [{self.name.upper()}] {msg}\n")

    def _on_connect(self, client, userdata, flags, rc):
        self.log("Terhubung ke Message Bus JDEQ")
        client.subscribe(self.sub_topic)

    def _on_message(self, client, userdata, msg):
        task = msg.payload.decode()
        self.log(f"Menerima: {task}")
        result = f"[{self.name}] {self.role}: '${task}' diproses."
        client.publish(self.pub_topic, result)
        self.log(f"Mengirim: {result}")

    def start(self):
        try:
            self.client.connect("127.0.0.1", 1883, 60)
            self.client.loop_start()
            self.log(f"Agen aktif — Peran: {self.role}")
            return True
        except Exception as e:
            self.log(f"Gagal: {e}")
            return False

    def stop(self):
        self.client.loop_stop()
        self.log("Agen berhenti.")

if __name__ == "__main__":
    print("Template Agen JDEQ siap. Gunakan dari modul lain.")
