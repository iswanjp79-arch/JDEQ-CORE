"""MICO Intent Engine — Filter, Parse, Route."""
import json
from pathlib import Path
from datetime import datetime

B = Path.home() / "JDEQ"
CONSTITUTION_FILE = B / "CONSTITUTION" / "identity.json"
REGISTRY_FILE = B / "GOVERNANCE" / "dewan_agen_registry.json"
SLASH_FILE = B / "GOVERNANCE" / "slash_registry.json"
LOG_FILE = B / "GOVERNANCE" / "decision_log.jsonl"

def load_json(path):
    if path.exists():
        return json.loads(path.read_text())
    return {}

def constitution_filter(prompt):
    """Lapisan 1: Periksa apakah prompt melanggar konstitusi."""
    constitution = load_json(CONSTITUTION_FILE)
    
    # Blokir prompt yang mencoba mengubah identitas
    forbidden = ["ubah digital_dna", "ubah identity", "hapus ssot", "ubah konstitusi"]
    for word in forbidden:
        if word in prompt.lower():
            return {"status": "REJECTED", "reason": f"Melanggar konstitusi: '{word}' tidak diizinkan."}
    
    return {"status": "APPROVED"}

def intent_parser(prompt):
    """Lapisan 2: Kenali intent dari prompt."""
    prompt_lower = prompt.lower()
    
    intents = {
        "audit": ["audit", "periksa", "cek", "temukan", "analisis"],
        "execute": ["buat", "kode", "script", "implementasi", "jalankan"],
        "strategy": ["roadmap", "strategi", "rencana", "blueprint"],
        "parse": ["konversi", "format", "parsing", "ekstrak"],
        "document": ["dokumen", "laporan", "checklist", "planner"],
        "verify": ["verifikasi", "ssot", "konsisten", "validasi"],
        "debug": ["bug", "error", "debug", "perbaiki"],
        "research": ["riset", "cari", "temukan", "library", "api"],
        "evolve": ["evolusi", "pola", "algoritma", "optimasi"]
    }
    
    for intent, keywords in intents.items():
        for kw in keywords:
            if kw in prompt_lower:
                return intent
    
    return "general"

def context_builder(prompt, intent):
    """Lapisan 3: Bangun konteks sebelum dikirim ke agen."""
    # Baca Slash Registry untuk wrapper
    slash_registry = load_json(SLASH_FILE)
    
    # Cek apakah prompt diawali slash command
    for slash, config in slash_registry.items():
        if prompt.startswith(slash):
            wrapper = config.get("wrapper", "")
            body = prompt[len(slash):].strip()
            return f"{wrapper}\n\n{body}" if body else wrapper
    
    # Default: gunakan prompt apa adanya
    return prompt

def route_to_agent(intent):
    """Lapisan 4: Pilih agen berdasarkan intent."""
    registry = load_json(REGISTRY_FILE)
    agents = registry.get("dewan_agen", {})
    
    routing = {
        "audit": "claude",
        "execute": "deepseek",
        "strategy": "gemini",
        "parse": "chatgpt",
        "document": "copilot_microsoft",
        "verify": "dola",
        "debug": "copilot_github",
        "research": "perplexity",
        "evolve": "emergent",
        "general": "chatgpt"
    }
    
    agent_id = routing.get(intent, "chatgpt")
    
    # Verifikasi agen tersedia
    if agent_id in agents and agents[agent_id]["status"] in ["AKTIF", "STANDBY"]:
        return agent_id
    return "chatgpt"

def process_prompt(prompt):
    """Pipeline lengkap: Filter → Parse → Build → Route."""
    # 1. Constitution Filter
    filter_result = constitution_filter(prompt)
    if filter_result["status"] == "REJECTED":
        log_decision(prompt, "REJECTED", filter_result["reason"])
        return {"status": "REJECTED", "reason": filter_result["reason"]}
    
    # 2. Intent Parser
    intent = intent_parser(prompt)
    
    # 3. Context Builder
    processed_prompt = context_builder(prompt, intent)
    
    # 4. Route to Agent
    agent = route_to_agent(intent)
    
    # 5. Log
    log_decision(prompt, agent, f"Intent: {intent}")
    
    return {
        "status": "APPROVED",
        "intent": intent,
        "agent": agent,
        "processed_prompt": processed_prompt
    }

def log_decision(prompt, agent, reason):
    with open(LOG_FILE, "a") as f:
        f.write(json.dumps({
            "timestamp": datetime.now().isoformat(),
            "prompt": prompt[:100],
            "agent": agent,
            "reason": reason
        }) + "\n")

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        prompt = " ".join(sys.argv[1:])
        result = process_prompt(prompt)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print("MICO Intent Engine — Siap.")
        print("Gunakan: python3 CORTEX/intent_engine.py 'prompt anda'")
