#!/usr/bin/env python3
import sys, json
RULES = {
    "lihat|foto|potret|ambil gambar": {"intent": "CAPTURE_IMAGE", "capability": "camera_capture"},
    "lapor|laporkan|kabar|bagaimana": {"intent": "GENERATE_REPORT", "capability": "report_generator"},
    "sehat|cek|kondisi|status": {"intent": "HEALTH_CHECK", "capability": "health_checker"},
    "halo|hai|pagi|siang|sore|malam": {"intent": "GREETING", "capability": "tts_speak"},
,
    "kirim|pesan|chat|tulis": {"intent": "SEND_MESSAGE", "capability": "message_sender", "response": "Baik, mengirim pesan."}
}
def detect(text):
    t = text.lower()
    for pattern, action in RULES.items():
        if any(word in t for word in pattern.split("|")): return action
    return {"intent": "UNKNOWN", "capability": None,
    "kirim|pesan|chat|tulis": {"intent": "SEND_MESSAGE", "capability": "message_sender", "response": "Baik, mengirim pesan."}
}
if __name__ == "__main__":
    txt = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "halo MICO"
    print(f"Intent: {json.dumps(detect(txt), indent=2)}")
    print("✅ Intent Graph aktif")
