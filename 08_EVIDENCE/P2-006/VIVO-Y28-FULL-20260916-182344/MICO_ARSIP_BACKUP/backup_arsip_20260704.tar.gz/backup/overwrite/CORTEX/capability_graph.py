#!/usr/bin/env python3
import sys, json, subprocess
CAPABILITIES = {
    "camera_capture": "bash ~/JDEQ/bridge/macro_listener.sh capture",
    "report_generator": "bash ~/JDEQ/bin/laporan_dewan.sh",
    "health_checker": "bash ~/JDEQ/bin/health_check.sh",
    "tts_speak": "termux-tts-speak 'Halo dari MICO'"
}
def execute(capability):
    cmd = CAPABILITIES.get(capability, "echo 'Tidak dikenal'")
    try:
        out = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        return {"status": "EXECUTED", "output": out.stdout.strip() or out.stderr.strip()}
    except Exception as e: return {"status": "FAILED", "output": str(e)}
if __name__ == "__main__":
    cap = sys.argv[1] if len(sys.argv) > 1 else "health_checker"
    print(f"Capability '{cap}': {json.dumps(execute(cap), indent=2)}")
    print("✅ Capability Graph aktif")
