#!/usr/bin/env python3
import json, os, subprocess, sys
from datetime import datetime
from pathlib import Path

# ============================================================
# KONFIGURASI INTENT & CAPABILITY
# ============================================================
INTENT_RULES = {
    "lihat|foto|potret|ambil gambar|jepret": {
        "intent": "CAPTURE_IMAGE",
        "capability": "camera_capture",
        "response": "📷 Baik, mengambil foto sekarang."
    },
    "lapor|laporkan|kabar|bagaimana|buat laporan": {
        "intent": "GENERATE_REPORT",
        "capability": "report_generator",
        "response": "📊 Baik, menyusun laporan."
    },
    "sehat|cek|kondisi|status|cek kesehatan|bagaimana kondisi": {
        "intent": "HEALTH_CHECK",
        "capability": "health_checker",
        "response": "🩺 Baik, memeriksa sistem."
    },
    "halo|hai|pagi|siang|sore|malam|assalamualaikum": {
        "intent": "GREETING",
        "capability": "tts_speak",
        "response": "Halo juga Mas Iswan. MICO siap."
    }
}

# ============================================================
# FUNGSI UTAMA
# ============================================================
def understand(text):
    """Menerjemahkan teks menjadi intent."""
    text_lower = text.lower()
    for pattern, action in INTENT_RULES.items():
        if any(word in text_lower for word in pattern.split("|")):
            return action
    return {"intent": "UNKNOWN", "capability": None, "response": "Maaf, perintah belum dikenali."}

def act(intent_data):
    """Menjalankan aksi berdasarkan capability."""
    capability = intent_data.get("capability")
    
    actions = {
        "camera_capture": "bash ~/JDEQ/bridge/macro_listener.sh capture",
        "report_generator": "bash ~/JDEQ/bin/laporan_dewan.sh",
        "health_checker": "bash ~/JDEQ/bin/health_check.sh",
        "tts_speak": f"termux-tts-speak '{intent_data.get('response', '')}'"
    }
    
    if capability not in actions:
        return {"status": "SKIPPED", "output": "No capability"}
    
    cmd = actions[capability]
    try:
        output = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        return {"status": "EXECUTED", "output": output.stdout.strip() or output.stderr.strip()}
    except Exception as e:
        return {"status": "FAILED", "output": str(e)}

def save_audit(text, intent_data, result):
    """Mencatat semua kejadian ke log audit."""
    audit_log = Path.home() / "JDEQ/AUDIT/brain_audit.jsonl"
    audit_log.parent.mkdir(parents=True, exist_ok=True)
    entry = {
        "timestamp": str(datetime.now()),
        "input": text,
        "intent": intent_data.get("intent"),
        "capability": intent_data.get("capability"),
        "result": result
    }
    with open(audit_log, "a") as f:
        f.write(json.dumps(entry) + "\n")
    return entry

# ============================================================
# SIKLUS UTAMA
# ============================================================
def run(text):
    """Siklus penuh: Understand -> Act -> Audit."""
    # 1. Pahami maksud
    intent_data = understand(text)
    print(f"🧠 MICO memahami: {intent_data['intent']}")
    print(f"💬 {intent_data['response']}")
    
    # 2. Jalankan aksi
    if intent_data['capability']:
        result = act(intent_data)
        print(f"⚡ Aksi: {result['status']}")
    else:
        result = {"status": "UNKNOWN", "output": ""}
    
    # 3. Catat audit
    audit_entry = save_audit(text, intent_data, result)
    print(f"📋 Audit tersimpan")
    
    return {"intent": intent_data, "result": result, "audit": audit_entry}

if __name__ == "__main__":
    text = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else input("Perintah: ")
    run(text)
