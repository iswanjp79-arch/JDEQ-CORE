#!/usr/bin/env python3
import os, json, subprocess
from datetime import datetime
def build_context(trigger=""):
    try:
        batt = os.popen("termux-battery-status 2>/dev/null | grep percentage | grep -o '[0-9]*'").read().strip()
        ram = os.popen("free -m | awk '/Mem/{print $7}'").read().strip()
        disk = os.popen("df -h ~ | awk 'NR==2 {print $5}'").read().strip()
        llm_alive = subprocess.run(["pgrep", "-f", "llama-server"], capture_output=True).returncode == 0
        return {"timestamp": str(datetime.now()), "trigger": trigger,
                "battery": batt or "N/A", "ram_mb": ram, "disk_pct": disk, "llm_alive": llm_alive}
    except: return {"error": "Gagal membaca konteks"}
if __name__ == "__main__":
    ctx = build_context("CORTEX_INIT")
    print(f"Context: {json.dumps(ctx, indent=2)}")
    print("✅ Context Builder aktif")
