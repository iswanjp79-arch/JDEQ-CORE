#!/data/data/com.termux/files/usr/bin/bash
# Global Listener — Dengarkan seluruh perubahan perangkat
source ~/JDEQ/scripts/jdeq_logger.sh
log_info "Global Listener: Memulai pemantauan seluruh perangkat."

MONITOR_DIRS=(
    "$HOME/storage/downloads"
    "$HOME/JDEQ"
    "$PREFIX/var/log"
)

for dir in "${MONITOR_DIRS[@]}"; do
    if [ -d "$dir" ]; then
        inotifywait -m -r -e create,modify,delete "$dir" 2>/dev/null | while read path event file; do
            log_info "GLOBAL EVENT: $path $event $file"
        done &
        log_info "Listener aktif: $dir"
    fi
done

wait
