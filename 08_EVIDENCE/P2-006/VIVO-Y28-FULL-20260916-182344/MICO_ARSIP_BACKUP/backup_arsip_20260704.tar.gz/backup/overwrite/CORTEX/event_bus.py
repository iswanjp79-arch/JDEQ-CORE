#!/usr/bin/env python3
import json, os, time
from datetime import datetime
BUS_DIR = os.path.expanduser("~/JDEQ/CORTEX/events")
os.makedirs(BUS_DIR, exist_ok=True)
def publish(event_type, payload=None):
    if payload is None: payload = {}
    event = {"id": datetime.now().strftime("%Y%m%d%H%M%S%f"),
             "timestamp": str(datetime.now()), "type": event_type, "payload": payload}
    with open(os.path.join(BUS_DIR, f"evt_{event['id']}.json"), 'w') as f:
        json.dump(event, f)
    return event
publish("SYSTEM_BOOT", {"status": "Event Bus Ready"})
print("✅ Event Bus aktif")
