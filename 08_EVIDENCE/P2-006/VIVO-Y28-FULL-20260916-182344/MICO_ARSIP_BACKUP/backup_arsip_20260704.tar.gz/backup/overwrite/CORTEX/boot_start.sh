#!/data/data/com.termux/files/usr/bin/bash
# MICO Init — Boot Sequence, Pemulihan Cerdas
source ~/JDEQ/scripts/jdeq_logger.sh
log_info "MICO Init: Booting..."

# Cek apakah JDEQ dijalankan oleh system boot
if [ "$1" = "--boot" ]; then
    log_info "MICO Init: System boot detected."
    ~/JDEQ/scripts/startup_core.sh
    sleep 2
fi

# Cek kesehatan
pgrep -x mosquitto || mosquitto -d
pgrep -x sshd || sshd -p 8022
pgrep -x crond || crond

# Jalankan MICO Cortex V2
pgrep -f mico_cortex_v2.py || python3 ~/JDEQ/CORTEX/mico_cortex_v2.py &

log_info "MICO Init: Boot sequence selesai."
