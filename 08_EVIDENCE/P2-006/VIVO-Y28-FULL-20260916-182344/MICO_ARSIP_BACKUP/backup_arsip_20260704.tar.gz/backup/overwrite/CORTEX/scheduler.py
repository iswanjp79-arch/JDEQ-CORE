"""MICO Executive Scheduler — Jadwal + Event Bus + Response Merger"""
import json, os, time
from pathlib import Path
from datetime import datetime

B = Path.home() / "JDEQ"
INTENT_FILE = B / "GOVERNANCE" / "decision_log.jsonl"
QUEUE_FILE = B / "RUNTIME" / "task_queue.json"
LOG_FILE = B / "logs" / "scheduler.log"

def log(msg):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}\n")

def run_scheduler():
    """Loop utama — eksekusi intent dari decision log."""
    log("Executive Scheduler — Mulai.")
    
    while True:
        # 1. Baca decision log untuk intent baru
        if INTENT_FILE.exists():
            lines = INTENT_FILE.read_text().strip().splitlines()
            for line in lines[-5:]:  # 5 intent terakhir
                try:
                    entry = json.loads(line)
                    intent = entry.get("intent", "general")
                    agent = entry.get("agent", "chatgpt")
                    prompt = entry.get("prompt", "")
                    
                    # 2. Tambahkan ke task queue
                    queue = json.loads(QUEUE_FILE.read_text()) if QUEUE_FILE.exists() else []
                    queue.append({
                        "intent": intent,
                        "agent": agent,
                        "prompt": prompt[:100],
                        "timestamp": datetime.now().isoformat()
                    })
                    QUEUE_FILE.parent.mkdir(parents=True, exist_ok=True)
                    QUEUE_FILE.write_text(json.dumps(queue, indent=2))
                    
                    log(f"Task ditambahkan: {intent} → {agent}")
                except:
                    pass
        
        time.sleep(60)  # Cek setiap 60 detik

if __name__ == "__main__":
    run_scheduler()
