"""Policy Engine V2 — Validasi setiap event sebelum diproses"""
import json
from pathlib import Path
from datetime import datetime

B = Path.home() / "JDEQ"
LOG_FILE = B / "logs" / "policy_v2.log"

def log(msg):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{datetime.now().strftime('%H:%M:%S')}] [POLICY] {msg}\n")

POLICIES = {
    "APK_INSTALLED": {
        "allowed": False,
        "reason": "Instalasi APK harus diverifikasi manual.",
        "action": "karantina"
    },
    "GIT_CHANGE": {
        "allowed": True,
        "reason": "Git change diizinkan dengan audit.",
        "action": "catat_ssot"
    },
    "SSOT_CHANGE": {
        "allowed": True,
        "reason": "SSOT change diizinkan dengan backup.",
        "action": "backup_dulu"
    },
    "FILE_CHANGE": {
        "allowed": True,
        "reason": "File change diizinkan.",
        "action": "catat_log"
    },
    "default": {
        "allowed": False,
        "reason": "Event tidak dikenal, butuh audit manual.",
        "action": "karantina"
    }
}

def validate_event(event_type, detail):
    policy = POLICIES.get(event_type, POLICIES["default"])
    if policy["allowed"]:
        log(f"DIIZINKAN: {event_type} → {policy['reason']}")
        return True, policy["action"]
    else:
        log(f"DITOLAK: {event_type} → {policy['reason']}")
        return False, policy["action"]

if __name__ == "__main__":
    log("Policy Engine V2 siap.")
