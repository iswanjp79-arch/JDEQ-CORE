#!/data/data/com.termux/files/usr/bin/bash
# MICO Detector — Mata & Telinga Sistem
# Mendeteksi: APK install, Git pull, file baru, USB, network

LOG_DIR=~/JDEQ/logs/detector
EVENT_FILE=~/JDEQ/logs/detector/events.log

mkdir -p $LOG_DIR

log_event() {
    local type="$1"
    local detail="$2"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] [$type] $detail" >> $EVENT_FILE
    echo "[$timestamp] [$type] $detail"
}

# Monitor direktori APK (termasuk download)
APK_DIR=~/storage/downloads
if [ -d "$APK_DIR" ]; then
    log_event "SYSTEM" "Detector mulai memonitor: $APK_DIR"
    inotifywait -m -e create,moved_to --format '%f' "$APK_DIR" 2>/dev/null | while read file; do
        if echo "$file" | grep -q '\.apk$'; then
            log_event "APK_INSTALLED" "$file"
        fi
    done &
fi

# Monitor direktori JDEQ (Git, config, SSOT)
JDEQ_DIR=~/JDEQ
log_event "SYSTEM" "Detector mulai memonitor: $JDEQ_DIR"
inotifywait -m -r -e modify,create,delete,move --format '%w%f %e' "$JDEQ_DIR" 2>/dev/null | while read path event; do
    # Abaikan file log dan cache
    if echo "$path" | grep -qv '\.log\|\.cache\|__pycache__'; then
        if echo "$path" | grep -q '\.git'; then
            log_event "GIT_CHANGE" "$path ($event)"
        elif echo "$path" | grep -q 'SSOT\|GOVERNANCE'; then
            log_event "SSOT_CHANGE" "$path ($event)"
        else
            log_event "FILE_CHANGE" "$path ($event)"
        fi
    fi
done &

log_event "SYSTEM" "Detector aktif — memonitor APK, Git, SSOT, dan file sistem."
wait
