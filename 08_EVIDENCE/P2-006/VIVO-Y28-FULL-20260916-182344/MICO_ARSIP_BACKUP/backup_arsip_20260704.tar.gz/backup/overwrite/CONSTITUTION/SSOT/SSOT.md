# SSOT JDEQ V3.0
Dokumen ini adalah sumber kebenaran tunggal untuk arsitektur JDEQ.
Semua keputusan arsitektur tercatat di sini.
