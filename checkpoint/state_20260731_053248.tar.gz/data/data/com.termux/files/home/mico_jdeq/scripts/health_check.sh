#!/data/data/com.termux/files/usr/bin/bash
echo "=============================================="
echo "  SCOUT - HEALTH CHECK $(date +%H:%M:%S)"
echo "=============================================="
echo "Layanan Lokal:"
echo "  SSHd    : $(pgrep sshd >/dev/null && echo '✅' || echo '❌')"
echo "  Crond   : $(pgrep crond >/dev/null && echo '✅' || echo '❌')"
echo "  Ollama  : $(pgrep ollama >/dev/null && echo '✅' || echo '❌')"

echo ""
echo "Koneksi Node:"
ping -c 1 -W 2 192.168.1.4 > /dev/null 2>&1 && echo "  Z83 ($(ssh z83 'hostname' 2>/dev/null || echo 'GAGAL')) : ✅" || echo "  Z83 : ❌ OFFLINE"
ping -c 1 -W 2 192.168.1.5 > /dev/null 2>&1 && echo "  PC i5 ($(ssh z83-lan 'hostname' 2>/dev/null || echo 'GAGAL')): ✅" || echo "  PC i5: ❌ OFFLINE"
echo "=============================================="
